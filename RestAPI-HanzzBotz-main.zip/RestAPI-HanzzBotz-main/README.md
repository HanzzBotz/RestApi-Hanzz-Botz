<h1 align="center">Zero YT7 <img src="https://user-images.githubusercontent.com/1303154/88677602-1635ba80-d120-11ea-84d8-d263ba5fc3c0.gif" width="40px" alt=""><br></h1>
<p align="center">
<img src="https://i.ibb.co/YDYS80p/zero.jpg" />
</p>

<p align="center">

- 👼 My name is Zero YT7

- 🗣️ I am 18 years old 

- 🔭 I am Not programmer
 
- 😎 I am like Wibu
</p>

-------

## ```FOLLOW ALL SOSIALMEDIA ME```
<p align="center">
<a href="https://instagram.com/ZeroYT7"><img src="https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white"/> 
<a href="https://wa.me/6281212083267"><img src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<a href="https://youtube.com/ZeroYT7"><img src="https://img.shields.io/badge/YouTube Zero YT7-ff0000?style=for-the-badge&logo=youtube&logoColor=ff000000&link=https://youtube.com/ZeroYT7" /><br>
<a href="https://tiktok.com/@_zeroyt7"><img src="https://img.shields.io/badge/Tiktok Zero YT7-black?style=for-the-badge&logo=tiktok&logoColor=ff000000&link=https://tiktok.com/@zeroyt7" /></a>
</p>

## ```DONASI```

- [`DANA,GOPAY,TSEL`](081387127465)

## ```GROUP BOT```

- [`GROUP WA`](https://chat.whatsapp.com/BM0HVJKYR2BI8JJUlQO2ue)</a>

## ```THANKS TO```
- Allah S.W.T
- Ortu
- Fxc7
- Farhan
- Ojan
- Eka Danuarta
- Zhirr
```
